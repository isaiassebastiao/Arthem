menuButton.addEventListener('click', ()=>{
    menuLinks.style.display = 'flex';
});
closeMenuButton.addEventListener('click', ()=>{
    menuLinks.style.display = 'none';
});

