import { core } from "../core/core.js";
export var checkArtworkStatus = async artwork_id =>{
    
    const form_data = new FormData();
    form_data.set('id', artwork_id);

    const server_response = await core('getArtwork', form_data);
    return server_response.data.status == 4;
}