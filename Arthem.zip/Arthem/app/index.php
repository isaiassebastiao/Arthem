<?php
    require_once('backend/config/DataBase.php');
    require_once('backend/models/Artist.php');
    require_once('backend/models/ArtWork.php');
    require_once('backend/models/Notification.php');
    require_once('backend/models/ArtistReport.php');
    require_once('backend/validator/validator.php');
    require_once('backend/controllers/ArthemController.php');
