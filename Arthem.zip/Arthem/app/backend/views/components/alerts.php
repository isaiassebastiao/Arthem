<link rel="stylesheet" href="../../../frontend/public/css/components/alert.css">
<aside class="alert-modal">
    <div class="alert">
        <p id="alert_message">Bem vindo(a) ao Painel de Artistas</p>
    </div>
</aside>