</div>
    <style>strong{display: block;line-height: 32px;}ul{padding: 0;list-style: none;}section p, section li{line-height: 22px;font-size: 14px;}</style>
    <footer>
        <section class="section-4">

            <div class="about-us">
                <strong style="margin-bottom: -12px;">Sobre</strong>
                <p>A Arthem é uma aplicação criada para promover a arte angolana, dando visibilidade a artistas locais e facilitando a exposição e a venda das suas obras.</p>
            </div>

            <div class="quick-links">
                <strong>Links Rápidos</strong>
                <ul>
                    <li><a href="../pages/gallery.php?page=gallery">Obras</a></li>
                    <li><a href="../pages/artists.php?page=artists">Artistas</a></li>
                    <li><a href="../pages/about.php?page=about">Sobre</a></li>
                </ul>
            </div>

            <div class="contact">
                <strong>Contacto</strong>
                <ul>
                    <li>E-mail: isaiassebastiao217@gmail.com</li>
                    <li>Tel: +244 948772757</li>
                </ul>
            </div>

        </section>
        <section class="section-5">
            <p>Arthem &copy; 2025 Todos os Direitos Reservados. Design by WeirdBoy</p>
        </section>
    </footer>
</body>
</html>