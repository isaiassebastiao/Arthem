<?php
    require_once('../components/header.php');
?>

<main>
    <section class='artists-and-events-main-section'>
        <h1>Agenda Cultural</h1>
        <p>Eventos, exposições e feiras de arte.</p>

        <div class='event-list'>
            <div class='event-card'>
                <div class='img-placeholder'></div>
                <h3 class='card-title'>Nome do Evento</h3>
                <p class='card-info'>Data • Local</p>
            </div>
            <div class='event-card'>
                <div class='img-placeholder'></div>
                <h3 class='card-title'>Nome do Evento</h3>
                <p class='card-info'>Data • Local</p>
            </div>
        </div>
    </section>

    
</main>