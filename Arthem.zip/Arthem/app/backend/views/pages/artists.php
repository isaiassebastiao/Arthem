<?php
    require_once('../components/header.php');
?>
<main>
    <section class='artists-and-events-main-section'>
            <h1>Artistas</h1>
            <p>Criadores que dão vida à arte angolana.</p>
    
            <div class='grid-container' id="container"></div>
            
    </section>
    <!---
        <section class="about-section-5">
            <p style="text-align:center">&copy; Arthem — Todos os direitos reservados.</p>
        </section>
    -->
</main>
<script type="module" src="../../../frontend/src/pages/artists.js"></script>