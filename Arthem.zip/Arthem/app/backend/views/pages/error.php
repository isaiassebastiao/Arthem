<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erro #404</title>
    <link rel="stylesheet" href="../../../frontend/public/css/index.css">
    <link rel="stylesheet" href="../../../frontend/public/css/pages/error.css">
</head>
<body>
    <section class="error-section">
        <h1>Esgotou o tempo limite de conexão com o servidor</h1>
        <p><a href="../pages/home.php">tentar novamente</a></p>
    </section>
</body>
</html>
